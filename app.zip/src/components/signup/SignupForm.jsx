import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Formik } from 'formik';
import * as Yup from 'yup';
import useRegistrationWithApproval from '../../hooks/useRegistrationWityhApproval.js';
import { Ionicons } from '@expo/vector-icons';

const SignUpForm = ({ navigation }) => {
  const { 
    registerUser, 
    registerWithGoogle, 
    isRegistering, 
    registrationError,
    clearError 
  } = useRegistrationWithApproval();

  const SignUpSchema = Yup.object().shape({
    email: Yup.string()
      .required('Email è richiesta')
      .email('Inserisci un indirizzo email valido'),
    password: Yup.string()
      .required('Password è richiesta')
      .min(6, 'La password deve contenere almeno 6 caratteri'),
    confirmPassword: Yup.string()
      .required('Conferma password è richiesta')
      .oneOf([Yup.ref('password')], 'Le password non corrispondono'),
    displayName: Yup.string()
      .required('Nome è richiesto')
      .min(2, 'Il nome deve contenere almeno 2 caratteri'),
  });

  const handleEmailRegistration = async (values) => {
    clearError();
    
    const result = await registerUser(
      values.email, 
      values.password, 
      {
        displayName: values.displayName
      }
    );

    if (result.success) {
      Alert.alert(
        'Registrazione Completata! 🎉',
        result.message,
        [
          {
            text: 'OK',
            onPress: () => navigation.navigate('PendingApproval')
          }
        ]
      );
    } else {
      Alert.alert('Errore Registrazione', result.error);
    }
  };

  const handleGoogleRegistration = async () => {
    clearError();
    
    const result = await registerWithGoogle();

    if (result.success) {
      Alert.alert(
        'Registrazione Google Completata! 🎉',
        result.message,
        [
          {
            text: 'OK',
            onPress: () => navigation.navigate('PendingApproval')
          }
        ]
      );
    } else {
      Alert.alert('Errore Registrazione Google', result.error);
    }
  };

  return (
    <View style={styles.container}>
      <Formik
        initialValues={{
          email: '',
          password: '',
          confirmPassword: '',
          displayName: ''
        }}
        validationSchema={SignUpSchema}
        onSubmit={handleEmailRegistration}
      >
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          values,
          errors,
          touched,
          isValid
        }) => (
          <View>
            {/* Campo Nome */}
            <View style={styles.inputField}>
              <TextInput
                style={styles.inputText}
                placeholder="Nome completo"
                placeholderTextColor="#bbb"
                onChangeText={handleChange('displayName')}
                onBlur={handleBlur('displayName')}
                value={values.displayName}
                autoCapitalize="words"
              />
            </View>
            {touched.displayName && errors.displayName && (
              <Text style={styles.errorText}>{errors.displayName}</Text>
            )}

            {/* Campo Email */}
            <View style={styles.inputField}>
              <TextInput
                style={styles.inputText}
                placeholder="Email"
                placeholderTextColor="#bbb"
                onChangeText={handleChange('email')}
                onBlur={handleBlur('email')}
                value={values.email}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>
            {touched.email && errors.email && (
              <Text style={styles.errorText}>{errors.email}</Text>
            )}

            {/* Campo Password */}
            <View style={styles.inputField}>
              <TextInput
                style={styles.inputText}
                placeholder="Password"
                placeholderTextColor="#bbb"
                onChangeText={handleChange('password')}
                onBlur={handleBlur('password')}
                value={values.password}
                secureTextEntry
                autoCapitalize="none"
              />
            </View>
            {touched.password && errors.password && (
              <Text style={styles.errorText}>{errors.password}</Text>
            )}

            {/* Campo Conferma Password */}
            <View style={styles.inputField}>
              <TextInput
                style={styles.inputText}
                placeholder="Conferma Password"
                placeholderTextColor="#bbb"
                onChangeText={handleChange('confirmPassword')}
                onBlur={handleBlur('confirmPassword')}
                value={values.confirmPassword}
                secureTextEntry
                autoCapitalize="none"
              />
            </View>
            {touched.confirmPassword && errors.confirmPassword && (
              <Text style={styles.errorText}>{errors.confirmPassword}</Text>
            )}

            {/* Bottone Registrazione Email */}
            <TouchableOpacity
              style={[
                styles.btnContainer,
                { opacity: !isValid || isRegistering ? 0.6 : 1 }
              ]}
              onPress={handleSubmit}
              disabled={!isValid || isRegistering}
            >
              <View style={styles.btnContent}>
                {isRegistering ? (
                  <>
                    <ActivityIndicator size="small" color="#fff" />
                    <Text style={styles.btnText}>Registrando...</Text>
                  </>
                ) : (
                  <Text style={styles.btnText}>Registrati</Text>
                )}
              </View>
            </TouchableOpacity>

            {/* Separatore */}
            <View style={styles.separator}>
              <View style={styles.separatorLine} />
              <Text style={styles.separatorText}>oppure</Text>
              <View style={styles.separatorLine} />
            </View>

            {/* Bottone Google */}
            <TouchableOpacity
              style={styles.googleBtn}
              onPress={handleGoogleRegistration}
              disabled={isRegistering}
            >
              <View style={styles.btnContent}>
                {isRegistering ? (
                  <ActivityIndicator size="small" color="#333" />
                ) : (
                  <>
                    <Ionicons name="logo-google" size={20} color="#333" />
                    <Text style={styles.googleBtnText}>Registrati con Google</Text>
                  </>
                )}
              </View>
            </TouchableOpacity>

            {/* Link al Login */}
            <View style={styles.loginLinkContainer}>
              <Text style={styles.loginLinkText}>Hai già un account? </Text>
              <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                <Text style={styles.loginLink}>Accedi</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </Formik>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 20,
  },
  inputField: {
    marginTop: 14,
    backgroundColor: '#111',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#444',
    paddingHorizontal: 15,
    marginHorizontal: 20,
    height: 56,
    justifyContent: 'center',
  },
  inputText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#fff',
  },
  errorText: {
    color: '#f00',
    fontSize: 12,
    marginTop: 5,
    marginLeft: 20,
    marginBottom: 5,
  },
  btnContainer: {
    marginTop: 35,
    alignItems: 'center',
    backgroundColor: '#07f',
    marginHorizontal: 20,
    justifyContent: 'center',
    height: 54,
    borderRadius: 10,
  },
  btnContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  btnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
  },
  separator: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 25,
    marginHorizontal: 20,
  },
  separatorLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#444',
  },
  separatorText: {
    color: '#666',
    paddingHorizontal: 15,
    fontSize: 14,
  },
  googleBtn: {
    alignItems: 'center',
    backgroundColor: '#fff',
    marginHorizontal: 20,
    justifyContent: 'center',
    height: 54,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  googleBtnText: {
    color: '#333',
    fontSize: 16,
    fontWeight: '600',
  },
  loginLinkContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 30,
  },
  loginLinkText: {
    color: '#666',
    fontSize: 14,
  },
  loginLink: {
    color: '#1af',
    fontSize: 14,
    fontWeight: '700',
  },
});

export default SignUpForm;