import SIZES from './SIZES';

module.exports = {
    SIZES
}